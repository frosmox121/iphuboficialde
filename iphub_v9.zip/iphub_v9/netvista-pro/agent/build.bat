@echo off
chcp 65001 >nul
cd /d "%~dp0"
set CSC_IDENTITY_AUTO_DISCOVERY=false
echo Instalando e compilando IPHub Monitor (sin login)...
call npm install
call npx --yes electron-builder --win portable --config.win.signAndEditExecutable=false
if exist dist\IPHub-Monitor.exe (
  if not exist ..\public\download mkdir ..\public\download
  copy /Y dist\IPHub-Monitor.exe ..\public\download\IPHub.exe
  echo OK: ..\public\download\IPHub.exe
) else (
  echo Fallo. Activa Modo desarrollador o ejecuta como Admin.
)
pause
