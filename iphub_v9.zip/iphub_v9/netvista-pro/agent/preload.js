const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('iphub', {
  call: (action, payload) => ipcRenderer.invoke('call', action, payload),
});
