module.exports = `<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>IPHub Monitor</title>
<style>
:root{--p:#0a1628;--s:#1a0b2e;--t:#e2e8f0;--m:#94a3b8;--ok:#10b981;--warn:#f59e0b;--bad:#ef4444;--c:#06b6d4}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(160deg,var(--p),var(--s));color:var(--t);min-height:100vh;padding:1.5rem}
header{display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem}
.logo{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#3b82f6,#8b5cf6);display:grid;place-items:center;font-weight:800}
h1{font-size:1.35rem}h1 small{display:block;font-size:.78rem;color:var(--m);font-weight:400}
.sp{flex:1}
.btn{border:0;border-radius:999px;padding:.55rem 1.1rem;font-weight:600;cursor:pointer;background:linear-gradient(135deg,#3b82f6,#8b5cf6);color:#fff}
.btn.g{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15)}
.btn.ok{background:rgba(16,185,129,.25);color:#6ee7b7}
.btn.bad{background:rgba(239,68,68,.25);color:#fca5a5}
.btn.sm{padding:.35rem .7rem;font-size:.8rem}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.2rem}
.card{background:rgba(15,23,42,.75);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:1.1rem}
.card h4{color:var(--m);font-size:.8rem;font-weight:500;margin-bottom:.35rem}
.card .v{font-size:1.6rem;font-weight:700}
.wide{grid-column:1/-1}
table{width:100%;border-collapse:collapse;font-size:.88rem}
th{text-align:left;color:var(--m);font-weight:500;padding:.55rem;border-bottom:1px solid rgba(255,255,255,.08)}
td{padding:.6rem .55rem;border-bottom:1px solid rgba(255,255,255,.05);vertical-align:middle}
.tag{display:inline-block;padding:.1rem .5rem;border-radius:999px;font-size:.72rem;font-weight:700}
.tag.ok{background:rgba(16,185,129,.2);color:#6ee7b7}
.tag.warn{background:rgba(245,158,11,.2);color:#fcd34d}
.tag.bad{background:rgba(239,68,68,.2);color:#fca5a5}
.tag.me{background:rgba(59,130,246,.25);color:#93c5fd}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--ok);margin-right:.4rem}
.actions{display:flex;flex-wrap:wrap;gap:.35rem}
#sub{color:var(--m);font-size:.85rem;margin-top:.25rem}
.bar{height:8px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;margin-top:.5rem}
.bar>i{display:block;height:100%;background:linear-gradient(90deg,var(--ok),var(--c));border-radius:99px}
@media(max-width:900px){.grid{grid-template-columns:1fr 1fr}}
</style></head><body>
<header>
  <div class="logo">IP</div>
  <div><h1>IPHub Monitor<small id="sub">Escaneando red local…</small></h1></div>
  <div class="sp"></div>
  <button class="btn g" id="btn-scan">Reescanear ahora</button>
</header>
<div class="grid" id="g"></div>
<script>
const F = (a,p) => window.iphub.call(a,p);
function riskTag(r){
  if(r>=60) return '<span class="tag bad">Riesgo alto</span>';
  if(r>=30) return '<span class="tag warn">Riesgo medio</span>';
  return '<span class="tag ok">Bajo riesgo</span>';
}
async function load(){
  const d = await F('summary');
  if(d.error){ document.getElementById('sub').textContent = d.error; return; }
  document.getElementById('sub').textContent = (d.scanning?'Escaneando ':'') + (d.cidr||'') + (d.scannedAt?(' · '+new Date(d.scannedAt).toLocaleTimeString()):'');
  const score = d.score??0;
  document.getElementById('g').innerHTML = `
    <div class="card"><h4>Dispositivos online</h4><div class="v">${d.online||0}</div></div>
    <div class="card"><h4>Desconocidos</h4><div class="v">${d.unknown||0}</div></div>
    <div class="card"><h4>Puertos críticos</h4><div class="v">${d.openCritical||0}</div></div>
    <div class="card"><h4>Puntaje seguridad</h4><div class="v">${score}<small style="font-size:.9rem;color:var(--m)"> /100 · ${d.level||''}</small>
      <div class="bar"><i style="width:${score}%"></i></div></div>
    <div class="card wide">
      <h4 style="margin-bottom:.8rem">Dispositivos en tu red ${d.me?('· este equipo: '+d.me):''}</h4>
      <table><thead><tr><th>IP</th><th>MAC</th><th>RTT</th><th>Puertos críticos</th><th>Estado</th><th>Acciones</th></tr></thead>
      <tbody>${(d.devices||[]).filter(x=>!x.ignored).map(x=>`<tr>
        <td><span class="dot"></span>${x.ip}${x.me?' <span class="tag me">este equipo</span>':''}${x.hostname?(' · '+x.hostname):''}</td>
        <td style="font-family:ui-monospace,monospace;font-size:.8rem">${x.mac||'—'}</td>
        <td>${x.rtt!=null?(x.rtt+' ms'):'—'}</td>
        <td>${(x.openCritical&&x.openCritical.length)?x.openCritical.join(', '):'<span style="color:var(--m)">ninguno</span>'}</td>
        <td>${x.trusted?'<span class="tag ok">Confiable</span>':(x.me?'<span class="tag me">Local</span>':riskTag(x.risk||0))}</td>
        <td class="actions">
          ${x.me?'':(x.trusted
            ?`<button class="btn sm g" data-a="untrust" data-ip="${x.ip}">Quitar confianza</button>`
            :`<button class="btn sm ok" data-a="trust" data-ip="${x.ip}">Confiar</button>`)}
          ${x.me?'':`<button class="btn sm g" data-a="ignore" data-ip="${x.ip}">Ocultar</button>
          <button class="btn sm bad" data-a="remove" data-ip="${x.ip}">Eliminar</button>`}
        </td>
      </tr>`).join('')||'<tr><td colspan="6" style="color:var(--m)">Sin dispositivos aún. Esperá el escaneo o tocá Reescanear.</td></tr>'}
      </tbody></table>
      <p style="margin-top:.9rem;color:var(--m);font-size:.82rem">Sin login. Los datos se guardan solo en este equipo (~/.iphub-agent.json). Confiar marca inventario base; Ocultar deja de mostrar; Eliminar quita del listado local.</p>
    </div>`;
}
document.getElementById('btn-scan').onclick = async ()=>{ document.getElementById('btn-scan').disabled=true; await F('scan'); document.getElementById('btn-scan').disabled=false; load(); };
document.addEventListener('click', async e=>{
  const b=e.target.closest('[data-a]'); if(!b) return;
  await F(b.dataset.a, b.dataset.ip); load();
});
load(); setInterval(load, 4000);
</script></body></html>`;
