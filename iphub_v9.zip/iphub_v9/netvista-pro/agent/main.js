const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
const core = require('./core'), html = require('./ui');

app.whenReady().then(() => {
  ipcMain.handle('call', async (_e, action, payload) => {
    try {
      if (action === 'scan') return await core.scan();
      if (action === 'summary') return core.summary();
      if (action === 'trust') return core.trust(payload);
      if (action === 'untrust') return core.untrust(payload);
      if (action === 'ignore') return core.ignore(payload);
      if (action === 'remove') return core.remove(payload);
      if (action === 'note') return core.note(payload?.ip, payload?.text);
      return core.summary();
    } catch (e) { return { error: e.message }; }
  });
  const file = path.join(os.tmpdir(), 'iphub-agent-ui.html');
  fs.writeFileSync(file, html);
  const win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 900, minHeight: 600,
    title: 'IPHub Monitor', backgroundColor: '#0b1d3a', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true },
  });
  win.loadFile(file);
  core.scan();
  setInterval(() => core.scan(), 60000);
});
app.on('window-all-closed', () => app.quit());
