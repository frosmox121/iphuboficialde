const { execFile } = require('child_process');
const os = require('os'), fs = require('fs'), path = require('path'), net = require('net');

const DATA = path.join(os.homedir(), '.iphub-agent.json');
function load() {
  try { return JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (_) {
    return { trusted: {}, ignored: {}, notes: {}, lastScan: null, devices: [] };
  }
}
function save(s) { fs.writeFileSync(DATA, JSON.stringify(s, null, 2)); }

function localCidr() {
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const i of ifs[name]) {
      if (i.family === 'IPv4' && !i.internal) {
        const parts = i.address.split('.').map(Number);
        return { me: i.address, mac: i.mac, cidr: `${parts[0]}.${parts[1]}.${parts[2]}.0/24`, iface: name };
      }
    }
  }
  return { me: '127.0.0.1', mac: '', cidr: '192.168.1.0/24', iface: '?' };
}

function ping(ip) {
  return new Promise(resolve => {
    const isWin = process.platform === 'win32';
    const args = isWin ? ['-n', '1', '-w', '600', ip] : ['-c', '1', '-W', '1', ip];
    const t0 = Date.now();
    execFile('ping', args, { timeout: 2000 }, (err, stdout) => {
      const ok = !err && /ttl|tiempo|time[=<]/i.test(String(stdout));
      resolve({ ip, online: ok, rtt: ok ? Date.now() - t0 : null });
    });
  });
}

function arpTable() {
  return new Promise(resolve => {
    execFile(process.platform === 'win32' ? 'arp' : 'arp', ['-a'], { timeout: 5000 }, (err, stdout) => {
      const map = {};
      for (const line of String(stdout || '').split(/\r?\n/)) {
        const m = line.match(/(\d+\.\d+\.\d+\.\d+)\s+([\w-]+)/i) || line.match(/(\d+\.\d+\.\d+\.\d+).*?((?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2})/i);
        if (m) map[m[1]] = (m[2] || '').replace(/-/g, ':').toLowerCase();
      }
      resolve(map);
    });
  });
}

function scanPort(host, port, ms = 400) {
  return new Promise(resolve => {
    const s = new net.Socket();
    let done = false;
    const fin = (open) => { if (done) return; done = true; try { s.destroy(); } catch (_) {} resolve(open); };
    s.setTimeout(ms);
    s.once('connect', () => fin(true));
    s.once('timeout', () => fin(false));
    s.once('error', () => fin(false));
    try { s.connect(port, host); } catch (_) { fin(false); }
  });
}

const RISK_PORTS = [21, 23, 445, 3389, 5900, 1433, 3306];

let scanning = false;
const state = load();

async function scan() {
  if (scanning) return state;
  scanning = true;
  try {
    const netInfo = localCidr();
    const base = netInfo.cidr.replace('/24', '');
    const prefix = base.split('.').slice(0, 3).join('.');
    const jobs = [];
    for (let i = 1; i <= 254; i++) jobs.push(ping(`${prefix}.${i}`));
    // limit concurrency
    const online = [];
    for (let i = 0; i < jobs.length; i += 40) {
      const chunk = await Promise.all(jobs.slice(i, i + 40));
      online.push(...chunk.filter(x => x.online));
    }
    const arp = await arpTable();
    const devices = [];
    for (const h of online) {
      const open = [];
      for (const p of RISK_PORTS) {
        if (await scanPort(h.ip, p, 350)) open.push(p);
      }
      const trusted = !!state.trusted[h.ip];
      const ignored = !!state.ignored[h.ip];
      const isMe = h.ip === netInfo.me;
      let risk = 0;
      if (open.length) risk += open.length * 15;
      if (!trusted && !isMe) risk += 20;
      if (open.includes(23) || open.includes(445)) risk += 25;
      risk = Math.min(100, risk);
      devices.push({
        ip: h.ip, mac: arp[h.ip] || (isMe ? netInfo.mac : '—'), rtt: h.rtt,
        openCritical: open, me: isMe, trusted, ignored,
        risk, note: state.notes[h.ip] || '',
        hostname: isMe ? os.hostname() : '',
      });
    }
    state.devices = devices;
    state.lastScan = new Date().toISOString();
    state.cidr = netInfo.cidr;
    state.me = netInfo.me;
    save(state);
  } finally { scanning = false; }
  return summary();
}

function summary() {
  const devs = (state.devices || []).filter(d => !d.ignored);
  const online = devs.length;
  const unknown = devs.filter(d => !d.trusted && !d.me).length;
  const critical = devs.reduce((n, d) => n + (d.openCritical?.length || 0), 0);
  const avg = (() => {
    const rs = devs.map(d => d.rtt).filter(x => x != null);
    return rs.length ? Math.round(rs.reduce((a, b) => a + b, 0) / rs.length) : null;
  })();
  let score = 100;
  score -= Math.min(40, unknown * 8);
  score -= Math.min(40, critical * 6);
  score = Math.max(1, Math.min(100, score));
  const level = score >= 80 ? 'Bueno' : score >= 50 ? 'Medio' : 'Crítico';
  return {
    scanning, cidr: state.cidr, me: state.me, scannedAt: state.lastScan,
    online, unknown, alerts: critical, avg, score, level, openCritical: critical,
    devices: state.devices || [],
  };
}

function trust(ip) { state.trusted[ip] = true; delete state.ignored[ip]; save(state); return summary(); }
function untrust(ip) { delete state.trusted[ip]; save(state); return summary(); }
function ignore(ip) { state.ignored[ip] = true; save(state); return summary(); }
function remove(ip) {
  delete state.trusted[ip]; delete state.ignored[ip]; delete state.notes[ip];
  state.devices = (state.devices || []).filter(d => d.ip !== ip);
  save(state); return summary();
}
function note(ip, text) { state.notes[ip] = String(text || '').slice(0, 200); save(state); return summary(); }

module.exports = { scan, summary, trust, untrust, ignore, remove, note };
