/**
 * IPHub — Backend real
 * -----------------------------------------------------------------------
 * Todo lo que hace este servidor es REAL:
 *  - Ping de verdad (spawnea el binario `ping` del sistema operativo)
 *  - ARP de verdad (spawnea `arp -a` y parsea la tabla ARP real del SO)
 *  - Escaneo de puertos TCP real (net.Socket.connect contra el host)
 *  - Traceroute (spawnea `traceroute`/`tracert` del sistema operativo)
 *  - Resolución DNS (módulo dns nativo de Node, consulta a los
 *    resolvers configurados en el sistema)
 *  - Geolocalización de IP real (API pública ip-api.com, sin mock)
 *  - Base de datos real persistida en disco (db.json vía lowdb) — nada
 *    se pierde al reiniciar el servidor.
 *
 * ADVERTENCIA LEGAL/ÉTICA (real, no de relleno): escanear puertos, hacer
 * ping sweep o traceroute contra hosts que no son tuyos y sin autorización
 * puede ser ILEGAL según la legislación de tu país. Usa esto solo sobre
 * tu propia red / equipos que administras.
 * -----------------------------------------------------------------------
 */
const path = require('path');
const fs = require('fs');
const net = require('net');
const dns = require('dns').promises;
const crypto = require('crypto');
const { execFile } = require('child_process');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
let nodemailer = null; try { nodemailer = require('nodemailer'); } catch (_) {}
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

// ---------- Cargar .env manualmente (sin dependencias extra) ----------
(function loadEnv() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, 'utf8').split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = trimmed.indexOf('=');
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    let val = trimmed.slice(idx + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (!(key in process.env)) process.env[key] = val.trim();
  }
})();

const PORT = parseInt(process.env.PORT || '3001', 10);
const JWT_SECRET = process.env.JWT_SECRET || 'inseguro_cambia_esto_en_.env';
const DEFAULT_CIDR = process.env.DEFAULT_SCAN_CIDR || '192.168.1.0/24';
const isWin = process.platform === 'win32';

if (JWT_SECRET === 'inseguro_cambia_esto_en_.env') {
  console.warn('⚠  Estás usando el JWT_SECRET por defecto. Creá un archivo .env (mirá .env.example) antes de exponer esto fuera de tu máquina.');
}

// ---------- Correo (SMTP) ----------
const SUPPORT_TO = process.env.SUPPORT_TO || 'iphuboficial@gmail.com';
const mailer = (nodemailer && process.env.SMTP_USER && process.env.SMTP_PASS)
  ? nodemailer.createTransport({ service: process.env.SMTP_SERVICE || 'gmail', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } })
  : null;
if (!mailer) console.warn('⚠  SMTP sin configurar (SMTP_USER / SMTP_PASS en .env): los correos NO se envían, los códigos se imprimen acá en consola.');
async function sendMail(to, subject, text, html, attachments) {
  if (!mailer) {
    console.log(`\n[MAIL no enviado] Para: ${to}\nAsunto: ${subject}\n${text}\n`);
    if (attachments?.length) console.log('[Adjuntos]', attachments.map(a => a.filename + ' (' + (a.content?.length || 0) + ' bytes)').join(', '));
    return false;
  }
  try {
    await mailer.sendMail({
      from: `"IPHub" <${process.env.SMTP_USER}>`,
      to, subject, text,
      html: html || undefined,
      attachments: attachments || undefined,
    });
    return true;
  } catch (e) { console.error('Error SMTP:', e.message); return false; }
}
const sha = v => crypto.createHash('sha256').update(String(v)).digest('hex');
async function issueCode(user) {
  const code = String(crypto.randomInt(100000, 1000000));
  db.get('users').find({ id: user.id }).assign({ verifyHash: sha(code), verifyExp: Date.now() + 15 * 60 * 1000, verifyTries: 0 }).write();
  return sendMail(user.email, `${code} es tu código de verificación de IPHub`,
    `Tu código de verificación de IPHub es: ${code}\nVence en 15 minutos. Si no lo pediste, ignorá este correo.`,
    `<div style="font-family:Segoe UI,Arial;max-width:420px;margin:auto;padding:28px;border-radius:16px;background:#0b1d3a;color:#fff"><h2 style="margin:0 0 8px">IPHub</h2><p>Tu código de verificación:</p><p style="font-size:34px;letter-spacing:8px;font-weight:700;color:#10b981">${code}</p><p style="color:#94a3b8;font-size:12px">Vence en 15 minutos.</p></div>`);
}

// ---------- Base de datos (persistida en disco) ----------
const dbFile = path.join(__dirname, 'db.json');
let prisma = null;
try { const { PrismaClient } = require('@prisma/client'); prisma = new PrismaClient(); } catch (e) { console.warn('Prisma client no cargó:', e.message); }
const state = global.__IPHUB_STATE || {}; const dirty = new Set(); let flushing = false;
async function flush() {
  if (flushing) return; flushing = true;
  try {
    while (dirty.size) {
      const k = [...dirty][0]; dirty.delete(k);
      if (prisma) {
        await prisma.collection.upsert({ where: { name: k }, update: { data: JSON.stringify(state[k]) }, create: { name: k, data: JSON.stringify(state[k]) } });
      } else {
        fs.writeFileSync(dbFile, JSON.stringify(state, null, 2));
      }
    }
  } catch (e) { console.error('DB persist:', e.message); try { fs.writeFileSync(dbFile, JSON.stringify(state, null, 2)); } catch (_) {} }
  flushing = false; if (dirty.size) flush();
}
const adapter = { read: () => state, write: d => { for (const k of Object.keys(d)) { if (JSON.stringify(d[k]) !== JSON.stringify(state[k])) { state[k] = JSON.parse(JSON.stringify(d[k])); dirty.add(k); } } flush(); return d; } };
const db = low(adapter);
db.defaults({
  users: [],
  audit: [],
  devices: [],
  scans: [],
  feedback: [],
  contacts: [],
}).write();

function addAudit(userEmail, action, detail) {
  db.get('audit')
    .unshift({
      id: crypto.randomUUID(),
      ts: new Date().toISOString(),
      user: userEmail || 'anónimo',
      action,
      detail,
    })
    .write();
  // Nos quedamos con las últimas 500 entradas para no crecer sin límite
  const all = db.get('audit').value();
  if (all.length > 500) db.set('audit', all.slice(0, 500)).write();
}

// ---------- Validaciones ----------
const IPV4_RE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
const HOSTNAME_RE = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

function isValidIPv4(s) {
  if (!IPV4_RE.test(s)) return false;
  return s.split('.').every(o => parseInt(o, 10) >= 0 && parseInt(o, 10) <= 255);
}
function isValidTarget(s) {
  return typeof s === 'string' && s.length <= 255 && (isValidIPv4(s) || HOSTNAME_RE.test(s));
}
function isValidCIDR(s) {
  const m = /^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/(\d{1,2})$/.exec(s || '');
  if (!m) return null;
  if (!isValidIPv4(m[1])) return null;
  const prefix = parseInt(m[2], 10);
  if (prefix < 0 || prefix > 32) return null;
  return { ip: m[1], prefix };
}
function ipToLong(ip) {
  return ip.split('.').reduce((acc, oct) => (acc << 8) + parseInt(oct, 10), 0) >>> 0;
}
function longToIp(long) {
  return [(long >>> 24) & 255, (long >>> 16) & 255, (long >>> 8) & 255, long & 255].join('.');
}

// ---------- App ----------
const app = express();
app.use(express.json({ limit: '12mb' }));
app.use(express.raw({ type: 'application/octet-stream', limit: '50mb' })); // para /speedtest/upload
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Auth middleware ----------
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No autenticado' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.get('users').find({ id: payload.sub }).value();
    if (!user) return res.status(401).json({ error: 'Usuario no existe' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
}

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, company: u.company || '', apiKey: u.apiKey, createdAt: u.createdAt, avatar: u.avatar || null, country: u.country || '', lang: u.lang || 'es' };
}

// ======================================================================
// AUTH
// ======================================================================
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, company, country, lang } = req.body || {};
  const em = String(email || '').toLowerCase().trim();
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em) || !password || password.length < 8) {
    return res.status(400).json({ error: 'Nombre, email válido y contraseña (mín. 8 caracteres) son obligatorios' });
  }
  let user = db.get('users').find({ email: em }).value();
  if (user && user.verified !== false) return res.status(409).json({ error: 'Ya existe una cuenta con ese email' });
  const passwordHash = await bcrypt.hash(password, 10);
  if (user) db.get('users').find({ id: user.id }).assign({ name, company: company || '', passwordHash, country: country || '', lang: lang || 'es' }).write();
  else {
    user = { id: crypto.randomUUID(), name, email: em, company: company || '', country: country || '', lang: lang || 'es', passwordHash, verified: false,
      apiKey: 'iphub_live_' + crypto.randomBytes(20).toString('hex'), createdAt: new Date().toISOString() };
    db.get('users').push(user).write();
  }
  const emailSent = await issueCode(user);
  addAudit(em, 'Cuenta creada (pendiente de verificación)', `Usuario: ${name}`);
  res.json({ needsVerification: true, email: em, emailSent });
});

app.post('/api/auth/resend', async (req, res) => {
  const user = db.get('users').find({ email: String((req.body || {}).email || '').toLowerCase() }).value();
  if (!user || user.verified !== false) return res.status(400).json({ error: 'No hay una verificación pendiente para ese correo' });
  res.json({ ok: true, emailSent: await issueCode(user) });
});

app.post('/api/auth/verify', (req, res) => {
  const { email, code } = req.body || {};
  const user = db.get('users').find({ email: String(email || '').toLowerCase() }).value();
  if (!user || user.verified !== false) return res.status(400).json({ error: 'No hay una verificación pendiente' });
  if (Date.now() > (user.verifyExp || 0)) return res.status(400).json({ error: 'El código venció. Pedí uno nuevo.' });
  if ((user.verifyTries || 0) >= 5) return res.status(429).json({ error: 'Demasiados intentos. Pedí un código nuevo.' });
  if (sha(String(code || '').trim()) !== user.verifyHash) {
    db.get('users').find({ id: user.id }).assign({ verifyTries: (user.verifyTries || 0) + 1 }).write();
    return res.status(400).json({ error: 'Código incorrecto' });
  }
  db.get('users').find({ id: user.id }).assign({ verified: true, verifyHash: null }).write();
  addAudit(user.email, 'Correo verificado', '-');
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: publicUser(db.get('users').find({ id: user.id }).value()) });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  const user = db.get('users').find({ email: String(email || '').toLowerCase() }).value();
  if (!user) return res.status(401).json({ error: 'Credenciales inválidas' });
  const ok = await bcrypt.compare(password || '', user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Credenciales inválidas' });
  if (user.verified === false) {
    const emailSent = await issueCode(user);
    return res.status(403).json({ error: 'Tenés que verificar tu correo. Te enviamos un código nuevo.', needsVerification: true, email: user.email, emailSent });
  }
  addAudit(user.email, 'Inicio de sesión', `IP origen: ${req.ip}`);
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: publicUser(user) });
});


// ---------- Recuperar contraseña ----------
app.post('/api/auth/forgot', async (req, res) => {
  const email = String((req.body || {}).email || '').toLowerCase().trim();
  if (!email) return res.status(400).json({ error: 'Ingresá tu correo' });
  const user = db.get('users').find({ email }).value();
  // Respuesta genérica para no filtrar si el mail existe
  if (!user) return res.json({ ok: true, emailSent: false, message: 'Si el correo existe, te enviamos un código.' });
  const emailSent = await issueCode(user);
  addAudit(user.email, 'Recuperación de contraseña solicitada', '-');
  res.json({ ok: true, emailSent, message: emailSent ? 'Código enviado a tu correo' : 'SMTP sin configurar: el código está en la consola del servidor' });
});

app.post('/api/auth/reset-password', async (req, res) => {
  const email = String((req.body || {}).email || '').toLowerCase().trim();
  const code = String((req.body || {}).code || '').trim();
  const password = String((req.body || {}).password || '');
  if (!email || !code || password.length < 8) {
    return res.status(400).json({ error: 'Correo, código y contraseña (mín. 8) son obligatorios' });
  }
  const user = db.get('users').find({ email }).value();
  if (!user) return res.status(400).json({ error: 'Código inválido o expirado' });
  if (!user.verifyHash || user.verifyHash !== sha(code)) {
    const tries = (user.verifyTries || 0) + 1;
    db.get('users').find({ id: user.id }).assign({ verifyTries: tries }).write();
    return res.status(400).json({ error: tries >= 5 ? 'Demasiados intentos. Pedí un código nuevo.' : 'Código incorrecto' });
  }
  if (user.verifyExp && Date.now() > user.verifyExp) {
    return res.status(400).json({ error: 'Código expirado. Solicitá uno nuevo.' });
  }
  const passwordHash = await bcrypt.hash(password, 10);
  db.get('users').find({ id: user.id }).assign({ passwordHash, verifyHash: null, verifyExp: null, verifyTries: 0 }).write();
  addAudit(user.email, 'Contraseña restablecida', '-');
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.post('/api/auth/logout', requireAuth, (req, res) => {
  addAudit(req.user.email, 'Cierre de sesión', '-');
  res.json({ ok: true });
});

app.post('/api/auth/regenerate-key', requireAuth, (req, res) => {
  const newKey = 'iphub_live_' + crypto.randomBytes(20).toString('hex');
  db.get('users').find({ id: req.user.id }).assign({ apiKey: newKey }).write();
  addAudit(req.user.email, 'Regeneración de clave API', '-');
  res.json({ apiKey: newKey });
});

app.put('/api/auth/profile', requireAuth, (req, res) => {
  const { name, company, country, lang } = req.body || {};
  db.get('users').find({ id: req.user.id }).assign({
    country: country !== undefined ? country : req.user.country, lang: lang || req.user.lang,
    name: name || req.user.name,
    company: company !== undefined ? company : req.user.company,
  }).write();
  addAudit(req.user.email, 'Perfil actualizado', '-');
  res.json({ user: publicUser(db.get('users').find({ id: req.user.id }).value()) });
});

// ======================================================================
// HERRAMIENTA: Analizador de IP (geolocalización real vía ip-api.com)
// ======================================================================
function fetchTimeout(url, ms = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { signal: ctrl.signal }).finally(() => clearTimeout(t));
}
async function geoLookup(ip) {
  // 1) ip-api.com
  try {
    const fields = 'status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query';
    const r = await fetchTimeout(`http://ip-api.com/json/${encodeURIComponent(ip)}?fields=${fields}`);
    const data = await r.json();
    if (data.status === 'success') return data;
  } catch (_) {}
  // 2) ipwho.is
  try {
    const r = await fetchTimeout(`https://ipwho.is/${encodeURIComponent(ip)}`);
    const d = await r.json();
    if (d.success !== false && d.country) {
      return {
        status: 'success', query: d.ip || ip, country: d.country, countryCode: d.country_code,
        regionName: d.region, city: d.city, zip: d.postal, lat: d.latitude, lon: d.longitude,
        timezone: (d.timezone && d.timezone.id) || d.timezone, offset: d.timezone && d.timezone.offset, currency: d.currency && d.currency.code,
        isp: (d.connection && d.connection.isp) || d.isp, org: d.connection && d.connection.org, as: d.connection && d.connection.asn ? ('AS'+d.connection.asn) : '',
        asname: d.connection && d.connection.org, reverse: '', mobile: !!(d.connection && d.connection.mobile), proxy: !!(d.security && d.security.proxy),
        hosting: !!(d.connection && d.connection.hosting), continent: d.continent, continentCode: d.continent_code, district: ''
      };
    }
  } catch (_) {}
  // 3) ipapi.co
  try {
    const r = await fetchTimeout(`https://ipapi.co/${encodeURIComponent(ip)}/json/`);
    const d = await r.json();
    if (!d.error && d.country_name) {
      return {
        status: 'success', query: d.ip || ip, country: d.country_name, countryCode: d.country_code,
        regionName: d.region, city: d.city, zip: d.postal, lat: d.latitude, lon: d.longitude,
        timezone: d.timezone, offset: 0, currency: d.currency, isp: d.org, org: d.org, as: d.asn,
        asname: d.org, reverse: '', mobile: false, proxy: false, hosting: false,
        continent: d.continent_code, continentCode: d.continent_code, district: ''
      };
    }
  } catch (_) {}
  return null;
}

app.post('/api/tools/ip-lookup', requireAuth, async (req, res) => {
  const { ip } = req.body || {};
  if (!ip || !isValidTarget(ip)) return res.status(400).json({ error: 'IP u host inválido' });
  try {
    const data = await geoLookup(ip);
    if (!data) return res.status(502).json({ error: 'No se pudo contactar el servicio de geolocalización (¿tenés salida a internet?)' });
    addAudit(req.user.email, 'Escaneo de IP ejecutado', `IP: ${ip} · ${data.isp || 'ISP desconocido'}`);
    data.ipVersion = String(ip).includes(':') ? 'IPv6' : 'IPv4';
    try { data.localTime = new Date().toLocaleString('es-AR', { timeZone: data.timezone }); } catch (_) {}
    data.osmUrl = `https://www.openstreetmap.org/?mlat=${data.lat}&mlon=${data.lon}#map=11/${data.lat}/${data.lon}`;
    // Detector VPN / Proxy (no Tor)
    const blob = `${data.isp || ''} ${data.org || ''} ${data.asname || ''} ${data.as || ''}`.toLowerCase();
    const vpnHints = /vpn|proxy|hosting|datacenter|data center|cloud|vps|server|digitalocean|linode|ovh|hetzner|amazon|aws|google cloud|microsoft azure|m247|leaseweb|colocrossing|psychz|choopa|vultr|contabo|nord|expressvpn|surfshark|mullvad|private internet|proton/.test(blob);
    data.isVpnOrProxy = !!(data.proxy || data.hosting || vpnHints);
    data.vpnConfidence = data.proxy ? 'alta' : data.hosting ? 'media-alta' : vpnHints ? 'media' : 'baja';
    data.vpnReason = data.proxy ? 'Marcado como proxy por el proveedor de geolocalización'
      : data.hosting ? 'IP de hosting/datacenter (típico de VPN o servidor)'
      : vpnHints ? 'ASN/ISP asociado a hosting, cloud o servicios VPN'
      : 'Sin indicios claros de VPN/proxy';
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: 'No se pudo contactar el servicio de geolocalización (¿tenés salida a internet?)' });
  }
});

// ======================================================================
// HERRAMIENTA: Escaneo de puertos TCP real
// ======================================================================
function scanPort(host, port, timeoutMs = 1200) {
  return new Promise(resolve => {
    const socket = new net.Socket();
    let done = false;
    const finish = open => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(open);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

const COMMON_SERVICES = {
  21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3',
  143: 'IMAP', 443: 'HTTPS', 445: 'SMB', 3306: 'MySQL', 3389: 'RDP', 5900: 'VNC', 8080: 'HTTP-Alt',
};
const CRITICAL_PORTS = new Set([21, 23, 445, 3389, 5900]);

app.post('/api/tools/port-scan', requireAuth, async (req, res) => {
  const { host, ports } = req.body || {};
  if (!host || !isValidTarget(host)) return res.status(400).json({ error: 'Host inválido' });

  let portList = Array.isArray(ports) ? ports : String(ports || '').split(/[,\s]+/);
  portList = portList.map(p => parseInt(p, 10)).filter(p => Number.isInteger(p) && p > 0 && p <= 65535);
  portList = [...new Set(portList)].slice(0, 200); // límite real por request, evita abuso
  if (portList.length === 0) return res.status(400).json({ error: 'No hay puertos válidos para escanear' });

  const results = [];
  const concurrency = 25;
  let idx = 0;
  async function worker() {
    while (idx < portList.length) {
      const port = portList[idx++];
      const open = await scanPort(host, port);
      results.push({ port, open, service: COMMON_SERVICES[port] || 'desconocido', critical: CRITICAL_PORTS.has(port) });
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, portList.length) }, worker));
  results.sort((a, b) => a.port - b.port);

  db.get('scans').unshift({
    id: crypto.randomUUID(), ts: new Date().toISOString(), host, ports: results,
  }).write();

  const openCritical = results.filter(r => r.open && r.critical).length;
  addAudit(req.user.email, 'Escaneo de puertos ejecutado', `Target: ${host} · ${portList.length} puertos · ${openCritical} críticos abiertos`);
  res.json({ host, results });
});

// ======================================================================
// HERRAMIENTA: Traceroute (spawnea el binario del sistema operativo)
// ======================================================================
app.post('/api/tools/traceroute', requireAuth, (req, res) => {
  const { target } = req.body || {};
  if (!target || !isValidTarget(target)) return res.status(400).json({ error: 'Destino inválido' });

  const cmd = isWin ? 'tracert' : 'traceroute';
  const args = isWin ? ['-d', '-h', '20', '-w', '1500', target] : ['-n', '-m', '20', '-w', '2', target];

  execFile(cmd, args, { timeout: 45000, maxBuffer: 2 * 1024 * 1024 }, (err, stdout, stderr) => {
    if (err && !stdout) {
      return res.status(500).json({
        error: `No se pudo ejecutar '${cmd}'. ¿Está instalado en este sistema? (${err.message})`,
      });
    }
    addAudit(req.user.email, 'Traceroute ejecutado', `Destino: ${target}`);
    res.json({ target, raw: stdout, tool: cmd });
  });
});

// Tracepacket: traza de paquetes (misma base que traceroute, parseo de hops)
app.post('/api/tools/tracepacket', requireAuth, (req, res) => {
  const { target } = req.body || {};
  if (!target || !isValidTarget(target)) return res.status(400).json({ error: 'Destino inválido' });
  const cmd = isWin ? 'tracert' : 'traceroute';
  const args = isWin ? ['-d', '-h', '30', '-w', '2000', target] : ['-n', '-q', '3', '-w', '2', target];
  execFile(cmd, args, { timeout: 45000, maxBuffer: 2 * 1024 * 1024 }, (err, stdout, stderr) => {
    if (err && !stdout) {
      return res.status(500).json({ error: `No se pudo ejecutar tracepacket (${cmd}). ${err.message}` });
    }
    const raw = stdout || '';
    const hops = [];
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*(\d+)\s+(.+)$/);
      if (!m) continue;
      const hop = m[1], rest = m[2].trim();
      const rtts = [...rest.matchAll(/(\d+[.,]?\d*)\s*ms/gi)].map(x => x[1].replace(',', '.'));
      while (rtts.length < 3) rtts.push(rtts.length ? rtts[0] : '—');
      let host = rest.replace(/\d+[.,]?\d*\s*ms/gi, '').replace(/\[.*?\]/g, '').replace(/\s+/g, ' ').replace(/\*/g, '').trim() || '*';
      hops.push({ hop, host, rtts: rtts.slice(0, 3) });
    }
    addAudit(req.user.email, 'Tracepacket ejecutado', `Destino: ${target}`);
    res.json({ target, raw, hops, tool: cmd });
  });
});

// ======================================================================
// HERRAMIENTA: DNS (módulo dns nativo de Node)
// ======================================================================
const pubResolver = new dns.Resolver();
pubResolver.setServers(['1.1.1.1', '8.8.8.8']);
// Intenta primero resolvers públicos (no dependen del DNS de tu router) y luego el del sistema
async function dnsQ(method, name) {
  let last;
  for (const r of [pubResolver, dns]) {
    try { return await r[method](name); } catch (e) { last = e; }
  }
  throw last;
}
const NO_DATA = new Set(['ENODATA', 'ENOTFOUND']);

app.post('/api/tools/dns-lookup', requireAuth, async (req, res) => {
  const { domain, type } = req.body || {};
  if (!domain || !HOSTNAME_RE.test(domain)) return res.status(400).json({ error: 'Dominio inválido' });
  const t = (type || 'A').toUpperCase();
  try {
    let records, note = null;
    if (t === 'A') records = await dnsQ('resolve4', domain);
    else if (t === 'AAAA') records = await dnsQ('resolve6', domain);
    else if (t === 'MX') records = (await dnsQ('resolveMx', domain)).map(r => `${r.priority} ${r.exchange}`);
    else if (t === 'NS') records = await dnsQ('resolveNs', domain);
    else if (t === 'TXT') records = (await dnsQ('resolveTxt', domain)).map(r => r.join(''));
    else if (t === 'CNAME' || t === 'ALIAS') {
      try {
        if (t === 'ALIAS') throw Object.assign(new Error('alias'), { code: 'ENODATA' });
        records = await dnsQ('resolveCname', domain);
      } catch (e) {
        if (!NO_DATA.has(e.code)) throw e;
        // Dominio raíz / sin CNAME: es normal (RFC 1034). Mostramos a qué resuelve realmente (ALIAS/ANAME aplanado).
        const a4 = await dnsQ('resolve4', domain).catch(() => []);
        const a6 = await dnsQ('resolve6', domain).catch(() => []);
        records = [...a4, ...a6];
        if (!records.length) throw e;
        note = t === 'ALIAS'
          ? `ALIAS/ANAME no existe como registro DNS: el proveedor lo "aplana" a registros A/AAAA. ${domain} resuelve a:`
          : `${domain} no tiene registro CNAME (un dominio raíz no puede tenerlo). Resuelve directamente a estos A/AAAA:`;
      }
    } else return res.status(400).json({ error: 'Tipo de registro no soportado' });

    addAudit(req.user.email, 'Consulta DNS', `${domain} · tipo ${t} · ${records.length} registros`);
    res.json({ domain, type: t, records, note });
  } catch (e) {
    res.status(422).json({ error: `Sin registros ${t} para ${domain} (${e.code || e.message})` });
  }
});

// ======================================================================
// HERRAMIENTA: Tabla ARP real (capa 2, dispositivos de la LAN)
// ======================================================================
function getArpTable() {
  return new Promise((resolve) => {
    execFile('arp', ['-a'], { timeout: 8000 }, (err, stdout) => {
      if (err && !stdout) return resolve([]);
      const ipRe = /(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/;
      const macRe = /([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}/;
      const out = [];
      for (const line of stdout.split('\n')) {
        const ipm = ipRe.exec(line);
        const macm = macRe.exec(line);
        if (ipm && macm) out.push({ ip: ipm[1], mac: macm[0].toUpperCase().replace(/-/g, ':') });
      }
      resolve(out);
    });
  });
}

app.get('/api/tools/arp-table', requireAuth, async (req, res) => {
  const table = await getArpTable();
  addAudit(req.user.email, 'Consulta tabla ARP', `${table.length} entradas`);
  res.json({ entries: table });
});

// ======================================================================
// DISPOSITIVOS / TOPOLOGÍA: descubrimiento real por ping sweep + ARP
// ======================================================================
function pingHost(ip) {
  return new Promise(resolve => {
    const args = isWin ? ['-n', '1', '-w', '800', ip] : ['-c', '1', '-W', '1', ip];
    const start = Date.now();
    execFile('ping', args, { timeout: 2000 }, (err, stdout) => {
      const rtt = Date.now() - start;
      if (err || !/TTL=/i.test(stdout)) return resolve({ ip, alive: false, rtt: null });
      const m = /(?:time|tiempo)[=<]\s*([\d.]+)/i.exec(stdout);
      resolve({ ip, alive: true, rtt: m ? parseFloat(m[1]) : rtt });
    });
  });
}

app.post('/api/devices/discover', requireAuth, async (req, res) => {
  const cidrInput = (req.body && req.body.cidr) || DEFAULT_CIDR;
  const parsed = isValidCIDR(cidrInput);
  if (!parsed) return res.status(400).json({ error: 'CIDR inválido (ej: 192.168.1.0/24)' });
  if (parsed.prefix < 24) return res.status(400).json({ error: 'Por rendimiento, usá /24 o una submáscara más chica' });

  const mask = parsed.prefix === 32 ? 0xffffffff : (~0 << (32 - parsed.prefix)) >>> 0;
  const network = ipToLong(parsed.ip) & mask;
  const hostCount = Math.min(254, Math.pow(2, 32 - parsed.prefix) - 2);
  const ips = Array.from({ length: hostCount }, (_, i) => longToIp((network + i + 1) >>> 0));

  const concurrency = 32;
  const alive = [];
  let idx = 0;
  async function worker() {
    while (idx < ips.length) {
      const ip = ips[idx++];
      const r = await pingHost(ip);
      if (r.alive) alive.push(r);
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));

  const arp = await getArpTable();
  const arpMap = new Map(arp.map(e => [e.ip, e.mac]));

  const devices = db.get('devices');
  const isBaseline = devices.value().length === 0; // 1er escaneo = inventario base (whitelist)
  for (const a of alive) {
    const mac = arpMap.get(a.ip) || null;
    let hostname = null;
    try { hostname = (await dns.reverse(a.ip))[0] || null; } catch (_) { /* sin PTR, es normal */ }

    const existing = devices.find({ ip: a.ip }).value();
    if (existing) {
      devices.find({ ip: a.ip }).assign({
        mac: mac || existing.mac,
        hostname: hostname || existing.hostname,
        lastSeen: new Date().toISOString(),
        lastRttMs: a.rtt,
        online: true,
      }).write();
    } else {
      devices.push({
        id: crypto.randomUUID(),
        ip: a.ip,
        mac,
        hostname,
        alias: hostname || a.ip,
        firstSeen: new Date().toISOString(),
        lastSeen: new Date().toISOString(),
        lastRttMs: a.rtt,
        online: true,
        trusted: isBaseline,
        suspicious: !isBaseline, // fuera del inventario base = desconocido
      }).write();
    }
  }
  // Marcar como offline a los que no respondieron esta vez
  const aliveIps = new Set(alive.map(a => a.ip));
  devices.filter(d => !aliveIps.has(d.ip)).forEach(d => devices.find({ ip: d.ip }).assign({ online: false }).write());

  addAudit(req.user.email, 'Descubrimiento de red ejecutado', `${cidrInput} · ${alive.length} hosts activos de ${ips.length} escaneados`);
  res.json({ scanned: ips.length, online: alive.length, devices: db.get('devices').value() });
});

app.get('/api/devices', requireAuth, (req, res) => {
  res.json({ devices: db.get('devices').value() });
});

app.put('/api/devices/:id', requireAuth, (req, res) => {
  const { alias, suspicious, trusted } = req.body || {};
  const device = db.get('devices').find({ id: req.params.id });
  if (!device.value()) return res.status(404).json({ error: 'Dispositivo no encontrado' });
  device.assign({
    ...(alias !== undefined ? { alias } : {}),
    ...(suspicious !== undefined ? { suspicious: !!suspicious } : {}),
    ...(trusted !== undefined ? { trusted: !!trusted } : {}),
  }).write();
  addAudit(req.user.email, 'Dispositivo actualizado', `${req.params.id} · ${JSON.stringify(req.body)}`);
  res.json({ device: device.value() });
});

app.delete('/api/devices/:id', requireAuth, (req, res) => {
  db.get('devices').remove({ id: req.params.id }).write();
  addAudit(req.user.email, 'Dispositivo eliminado del inventario', req.params.id);
  res.json({ ok: true });
});

// ======================================================================
// SPEEDTEST real (mide el enlace real entre el navegador y ESTE servidor;
// si corrés el server en tu router/VPS vas a medir tu enlace real a internet,
// si lo corrés en localhost vas a medir tu loopback — es honesto y esperable)
// ======================================================================
app.get('/api/tools/speedtest/download', requireAuth, (req, res) => {
  const sizeMb = Math.min(50, Math.max(1, parseInt(req.query.mb, 10) || 20));
  const bytes = sizeMb * 1024 * 1024;
  const chunk = crypto.randomBytes(64 * 1024);
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Length', bytes);
  let sent = 0;
  function pump() {
    let ok = true;
    while (sent < bytes && ok) {
      const remaining = bytes - sent;
      const piece = remaining >= chunk.length ? chunk : chunk.slice(0, remaining);
      ok = res.write(piece);
      sent += piece.length;
    }
    if (sent < bytes) res.once('drain', pump);
    else res.end();
  }
  pump();
});

app.post('/api/tools/speedtest/upload', requireAuth, (req, res) => {
  // express.raw ya consumió el body completo; con eso medimos bytes recibidos
  const bytes = req.body ? req.body.length : 0;
  res.json({ bytesReceived: bytes });
});

app.post('/api/tools/speedtest/log', requireAuth, (req, res) => {
  const { downloadMbps, uploadMbps, latencyMs, jitterMs } = req.body || {};
  addAudit(req.user.email, 'Prueba de velocidad ejecutada',
    `↓${(downloadMbps || 0).toFixed?.(1) ?? downloadMbps} Mbps · ↑${(uploadMbps || 0).toFixed?.(1) ?? uploadMbps} Mbps · lat ${latencyMs} ms · jitter ${jitterMs} ms`);
  res.json({ ok: true });
});

// ======================================================================
// DASHBOARD: puntaje de seguridad y métricas, calculados de datos reales
// ======================================================================
app.get('/api/dashboard/summary', requireAuth, (req, res) => {
  const devices = db.get('devices').value();
  const onlineDevices = devices.filter(d => d.online).length;
  const suspiciousDevices = devices.filter(d => d.suspicious).length;

  const lastScanByHost = new Map();
  for (const s of db.get('scans').value()) {
    if (!lastScanByHost.has(s.host)) lastScanByHost.set(s.host, s);
  }
  let openCritical = 0;
  for (const s of lastScanByHost.values()) {
    openCritical += s.ports.filter(p => p.open && p.critical).length;
  }

  const rtts = devices.filter(d => d.online && typeof d.lastRttMs === 'number').map(d => d.lastRttMs);
  const avgLatency = rtts.length ? Math.round(rtts.reduce((a, b) => a + b, 0) / rtts.length) : null;

  const hasData = devices.length > 0 || lastScanByHost.size > 0;
  // Sin datos no hay puntaje (antes daba 100/100 sobre la nada)
  const unknownPenalty = devices.length ? Math.round(40 * suspiciousDevices / devices.length) : 0;
  const score = hasData ? Math.max(1, Math.min(100, 100 - openCritical * 10 - unknownPenalty)) : null;

  res.json({
    hasData,
    devicesOnline: onlineDevices,
    devicesTotal: devices.length,
    activeAlerts: openCritical + suspiciousDevices,
    avgLatencyMs: avgLatency,
    anomalies: suspiciousDevices,
    securityScore: score,
    openCriticalPorts: openCritical,
    scannedHosts: lastScanByHost.size,
  });
});

// ======================================================================
// AUDITORÍA
// ======================================================================
app.get('/api/audit', requireAuth, (req, res) => {
  const limit = Math.min(500, parseInt(req.query.limit, 10) || 100);
  res.json({ entries: db.get('audit').value().slice(0, limit) });
});

app.get('/api/audit/export.csv', requireAuth, (req, res) => {
  const entries = db.get('audit').value();
  const header = 'timestamp,mail,accion,detalle\n';
  const rows = entries.map(e =>
    [e.ts, e.user, e.action, e.detail].map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')
  ).join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="audit-log.csv"');
  res.send(header + rows);
});

// ======================================================================
// FEEDBACK / CONTACTO (persistidos de verdad, sin envío de email real
// salvo que configures SMTP — ver README)
// ======================================================================
const own = (col, req) => db.get(col).filter({ user: req.user.email }).value();
const TICKET_COOLDOWN = 30 * 60 * 1000;

app.get('/api/feedback', requireAuth, (req, res) => res.json({ reviews: own('feedback', req) }));
app.post('/api/feedback', requireAuth, async (req, res) => {
  const { rating, comment } = req.body || {};
  if (!rating && !comment) return res.status(400).json({ error: 'Poné una calificación o un comentario' });
  const r = { id: crypto.randomUUID(), ts: new Date().toISOString(), user: req.user.email, rating: rating || null, comment: comment || '' };
  db.get('feedback').unshift(r).write();
  addAudit(req.user.email, 'Reseña enviada', `Rating: ${rating || '-'}`);
  const emailed = await sendMail(SUPPORT_TO, '[IPHub · Reseña] ' + (rating || '-') + '★', `De: ${req.user.name} <${req.user.email}>\nCalificación: ${rating || '-'}/5\n\n${comment || ''}`);
  res.json({ ok: true, review: r, emailed });
});
app.put('/api/feedback/:id', requireAuth, async (req, res) => {
  const r = db.get('feedback').find({ id: req.params.id, user: req.user.email });
  if (!r.value()) return res.status(404).json({ error: 'Reseña no encontrada' });
  const { rating, comment } = req.body || {};
  r.assign({ rating: rating || r.value().rating, comment: comment ?? r.value().comment, edited: new Date().toISOString() }).write();
  const v = r.value();
  addAudit(req.user.email, 'Reseña modificada', v.id);
  const emailed = await sendMail(SUPPORT_TO, '[IPHub · Reseña MODIFICADA]', `De: ${req.user.email}\nCalificación: ${v.rating}/5\n\n${v.comment}`);
  res.json({ ok: true, review: v, emailed });
});

app.delete('/api/feedback/:id', requireAuth, async (req, res) => {
  const found = db.get('feedback').find({ id: req.params.id, user: req.user.email }).value();
  if (!found) return res.status(404).json({ error: 'Reseña no encontrada' });
  db.get('feedback').remove({ id: req.params.id }).write();
  addAudit(req.user.email, 'Reseña eliminada', req.params.id);
  await sendMail(SUPPORT_TO, '[IPHub · Reseña ELIMINADA]',
    `El usuario ${req.user.name} <${req.user.email}> eliminó una reseña.\nID: ${req.params.id}\nCalificación: ${found.rating || '-'}\nComentario: ${found.comment || ''}`);
  res.json({ ok: true });
});

app.get('/api/contact', requireAuth, (req, res) => res.json({ tickets: own('contacts', req) }));
app.post('/api/contact', requireAuth, async (req, res) => {
  const { subject, message, files } = req.body || {};
  if (!subject || !message) return res.status(400).json({ error: 'Asunto y mensaje son obligatorios' });
  const last = own('contacts', req)[0];
  const wait = last ? TICKET_COOLDOWN - (Date.now() - new Date(last.ts)) : 0;
  if (wait > 0) return res.status(429).json({ error: `Podés crear otro ticket en ${Math.ceil(wait / 60000)} min. Mientras tanto podés modificar el anterior.` });

  // Adjuntos: hasta 5 archivos, 10 MB acumulados (base64 data URLs)
  let attachments = [];
  let metaFiles = [];
  if (Array.isArray(files) && files.length) {
    if (files.length > 5) return res.status(400).json({ error: 'Máximo 5 archivos por ticket' });
    let total = 0;
    for (const f of files) {
      const name = String(f.name || 'archivo').slice(0, 120);
      const data = String(f.data || '');
      const m = data.match(/^data:([^;]+);base64,(.+)$/);
      if (!m) return res.status(400).json({ error: `Archivo inválido: ${name}` });
      const buf = Buffer.from(m[2], 'base64');
      total += buf.length;
      if (total > 10 * 1024 * 1024) return res.status(400).json({ error: 'El total de adjuntos no puede superar 10 MB' });
      attachments.push({ filename: name, content: buf, contentType: m[1] });
      metaFiles.push({ name, size: buf.length, type: m[1] });
    }
  }

  const ticket = {
    id: crypto.randomUUID(), ts: new Date().toISOString(), user: req.user.email,
    subject, message, status: 'abierto', priority: false, files: metaFiles,
  };
  db.get('contacts').unshift(ticket).write();
  addAudit(req.user.email, 'Ticket de soporte creado', subject + (metaFiles.length ? ` (${metaFiles.length} adjuntos)` : ''));
  const fileList = metaFiles.length
    ? '\nAdjuntos:\n' + metaFiles.map(f => `- ${f.name} (${Math.round(f.size/1024)} KB)`).join('\n')
    : '';
  const emailed = await sendMail(
    SUPPORT_TO,
    `[IPHub · Ticket] ${subject}`,
    `Ticket ${ticket.id}\nFecha: ${ticket.ts}\nDe: ${req.user.name} <${req.user.email}>\nEmpresa: ${req.user.company || '-'}\n\nAsunto: ${subject}\n\n${message}${fileList}`,
    undefined,
    attachments
  );
  res.json({ ok: true, ticket, emailed });
});
app.put('/api/contact/:id', requireAuth, async (req, res) => {
  const t = db.get('contacts').find({ id: req.params.id, user: req.user.email });
  if (!t.value()) return res.status(404).json({ error: 'Ticket no encontrado' });
  const { subject, message } = req.body || {};
  t.assign({ subject: subject || t.value().subject, message: message || t.value().message, edited: new Date().toISOString() }).write();
  const v = t.value();
  addAudit(req.user.email, 'Ticket modificado', v.id);
  const emailed = await sendMail(SUPPORT_TO, `[IPHub · Ticket MODIFICADO${v.priority ? ' · PRIORIDAD' : ''}] ${v.subject}`, `Ticket ${v.id}\nDe: ${req.user.email}\n\n${v.message}`);
  res.json({ ok: true, ticket: v, emailed });
});
app.post('/api/contact/:id/priority', requireAuth, async (req, res) => {
  const t = db.get('contacts').find({ id: req.params.id, user: req.user.email });
  if (!t.value()) return res.status(404).json({ error: 'Ticket no encontrado' });
  t.assign({ priority: true, priorityAt: new Date().toISOString() }).write();
  const v = t.value();
  addAudit(req.user.email, 'Prioridad solicitada en ticket', v.id);
  const emailed = await sendMail(SUPPORT_TO, `[IPHub · PRIORIDAD] ${v.subject}`, `⚠ El usuario ${req.user.name} <${req.user.email}> pidió PRIORIDAD para el ticket ${v.id}.\n\nAsunto: ${v.subject}\n\n${v.message}`);
  res.json({ ok: true, ticket: v, emailed });
});

// ---------- Cuenta ----------
app.post('/api/account/password', requireAuth, async (req, res) => {
  const { current, next } = req.body || {};
  const u = db.get('users').find({ id: req.user.id });
  if (!next || next.length < 8) return res.status(400).json({ error: 'La nueva contraseña debe tener al menos 8 caracteres' });
  if (!(await bcrypt.compare(current || '', u.value().passwordHash))) return res.status(401).json({ error: 'La contraseña actual es incorrecta' });
  u.assign({ passwordHash: await bcrypt.hash(next, 10) }).write();
  addAudit(req.user.email, 'Contraseña cambiada', '-');
  res.json({ ok: true });
});
app.put('/api/account/avatar', requireAuth, (req, res) => {
  const { avatar } = req.body || {};
  if (avatar && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(avatar)) return res.status(400).json({ error: 'Imagen inválida (PNG, JPG o WEBP)' });
  if (avatar && avatar.length > 400000) return res.status(413).json({ error: 'La imagen es demasiado grande' });
  db.get('users').find({ id: req.user.id }).assign({ avatar: avatar || null }).write();
  addAudit(req.user.email, 'Foto de perfil actualizada', '-');
  res.json({ ok: true });
});
app.post('/api/account/delete/start', requireAuth, async (req, res) => {
  const u = db.get('users').find({ id: req.user.id });
  if (!(await bcrypt.compare((req.body || {}).password || '', u.value().passwordHash))) return res.status(401).json({ error: 'Contraseña incorrecta' });
  const emailSent = await issueCode(u.value());
  res.json({ ok: true, emailSent });
});
app.delete('/api/account', requireAuth, async (req, res) => {
  const u = db.get('users').find({ id: req.user.id });
  const user = u.value();
  if (!(await bcrypt.compare((req.body || {}).password || '', user.passwordHash))) return res.status(401).json({ error: 'Contraseña incorrecta' });
  const code = String((req.body || {}).code || '').trim();
  if (!user.verifyHash || user.verifyHash !== sha(code)) return res.status(401).json({ error: 'Código incorrecto' });
  if (user.verifyExp && Date.now() > user.verifyExp) return res.status(401).json({ error: 'Código expirado' });
  db.get('users').remove({ id: req.user.id }).write();
  ['contacts', 'feedback'].forEach(c => db.get(c).remove({ user: req.user.email }).write());
  res.json({ ok: true });
});

// ---------- Actividad (dashboard web: NO usa dispositivos, eso es del agente .exe) ----------
app.get('/api/dashboard/activity', requireAuth, (req, res) => {
  const audit = db.get('audit').filter({ user: req.user.email }).value();
  const day = Date.now() - 864e5, cnt = t => audit.filter(e => e.action.includes(t)).length;
  const rv = own('feedback', req).filter(r => r.rating);
  res.json({
    events24h: audit.filter(e => new Date(e.ts) > day).length, eventsTotal: audit.length,
    ipLookups: cnt('IP'), portScans: cnt('puertos') + cnt('Escaneo'), dnsQueries: cnt('DNS'), traces: cnt('Traceroute'),
    openTickets: own('contacts', req).filter(t => t.status === 'abierto').length,
    avgRating: rv.length ? +(rv.reduce((a, r) => a + r.rating, 0) / rv.length).toFixed(1) : null,
    memberSince: req.user.createdAt, recent: audit.slice(0, 5),
  });
});

// ======================================================================
// CIDR / Subredes — cálculo real (aritmética de bits, no requiere red)
// ======================================================================
app.post('/api/tools/subnet-calc', requireAuth, (req, res) => {
  const parsed = isValidCIDR(req.body && req.body.cidr);
  if (!parsed) return res.status(400).json({ error: 'CIDR inválido' });
  const { ip, prefix } = parsed;
  const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
  const ipLong = ipToLong(ip);
  const network = (ipLong & mask) >>> 0;
  const broadcast = (network | (~mask >>> 0)) >>> 0;
  const firstHost = prefix >= 31 ? network : network + 1;
  const lastHost = prefix >= 31 ? broadcast : broadcast - 1;
  const hosts = prefix >= 31 ? (prefix === 32 ? 1 : 2) : Math.pow(2, 32 - prefix) - 2;

  addAudit(req.user.email, 'Calculadora de subredes', `CIDR: ${ip}/${prefix}`);
  res.json({
    network: longToIp(network), mask: longToIp(mask), broadcast: longToIp(broadcast),
    firstHost: longToIp(firstHost), lastHost: longToIp(lastHost), usableHosts: hosts,
    cidr: `${longToIp(network)}/${prefix}`, wildcard: longToIp(~mask >>> 0),
  });
});

// ---------- Cambio de correo con doble verificación (correo viejo y nuevo) ----------
const rc = () => String(crypto.randomInt(100000, 1000000));
app.post('/api/account/email/start', requireAuth, async (req, res) => {
  const ne = String((req.body || {}).newEmail || '').toLowerCase().trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(ne)) return res.status(400).json({ error: 'Correo nuevo inválido' });
  if (db.get('users').find({ email: ne }).value()) return res.status(409).json({ error: 'Ese correo ya está en uso' });
  const c = rc();
  db.get('users').find({ id: req.user.id }).assign({ ec: { ne, oldHash: sha(c), stage: 'old', exp: Date.now() + 15 * 60 * 1000, tries: 0 } }).write();
  const sent = await sendMail(req.user.email, `${c} confirma el cambio de correo en IPHub`, `Código para autorizar el cambio de correo: ${c}\nVence en 15 minutos. Si no fuiste vos, cambiá tu contraseña.`);
  res.json({ ok: true, emailSent: sent });
});
app.post('/api/account/email/confirm', requireAuth, async (req, res) => {
  const { code } = req.body || {}; const u = db.get('users').find({ id: req.user.id }); const ec = u.value().ec;
  if (!ec || Date.now() > ec.exp) return res.status(400).json({ error: 'No hay un cambio de correo pendiente o venció' });
  if (ec.tries >= 5) return res.status(429).json({ error: 'Demasiados intentos. Empezá de nuevo.' });
  const h = sha(String(code || '').trim());
  if (ec.stage === 'old') {
    if (h !== ec.oldHash) { u.assign({ ec: { ...ec, tries: ec.tries + 1 } }).write(); return res.status(400).json({ error: 'Código incorrecto' }); }
    const c = rc(); u.assign({ ec: { ...ec, stage: 'new', newHash: sha(c), tries: 0 } }).write();
    const sent = await sendMail(ec.ne, `${c} verifica tu nuevo correo en IPHub`, `Código para verificar este correo como tu nuevo correo de IPHub: ${c}`);
    return res.json({ next: 'new', emailSent: sent });
  }
  if (h !== ec.newHash) { u.assign({ ec: { ...ec, tries: ec.tries + 1 } }).write(); return res.status(400).json({ error: 'Código incorrecto' }); }
  const old = req.user.email;
  for (const col of ['audit', 'feedback', 'contacts']) db.get(col).filter({ user: old }).each(x => { x.user = ec.ne; }).value();
  u.assign({ email: ec.ne, ec: null }).write(); db.write();
  addAudit(ec.ne, 'Correo cambiado', `${old} → ${ec.ne}`);
  res.json({ done: true, user: publicUser(u.value()) });
});


// ---------- Niveles / XP / Quizzes ----------
function ensureProgress(user) {
  const u = db.get('users').find({ id: user.id });
  const v = u.value() || {};
  if (v.level == null) u.assign({ level: 1, xp: 0, quizAt: 0 }).write();
  return db.get('users').find({ id: user.id }).value();
}
function xpForLevel(lv) { return Math.min(5000, 50 + lv * 12); }
app.get('/api/progress', requireAuth, (req, res) => {
  const u = ensureProgress(req.user);
  const need = xpForLevel(u.level || 1);
  res.json({ level: u.level || 1, xp: u.xp || 0, need, maxLevel: 150, quizCooldown: Math.max(0, (u.quizAt || 0) + 600000 - Date.now()) });
});
app.post('/api/quiz/submit', requireAuth, (req, res) => {
  const u = ensureProgress(req.user);
  const now = Date.now();
  if ((u.quizAt || 0) + 600000 > now) {
    return res.status(429).json({ error: `Cooldown de quiz: esperá ${Math.ceil(((u.quizAt || 0) + 600000 - now) / 60000)} min` });
  }
  const { correct = 0, total = 1, difficulty = 'medium' } = req.body || {};
  const mult = difficulty === 'hard' ? 1.5 : difficulty === 'easy' ? 0.7 : 1;
  let gain = Math.round(Math.max(5, Math.min(80, (Number(correct) / Math.max(1, Number(total))) * 40 * mult)));
  let level = u.level || 1, xp = (u.xp || 0) + gain;
  while (level < 150 && xp >= xpForLevel(level)) { xp -= xpForLevel(level); level++; }
  if (level >= 150) { level = 150; xp = Math.min(xp, xpForLevel(150) - 1); }
  db.get('users').find({ id: req.user.id }).assign({ level, xp, quizAt: now }).write();
  addAudit(req.user.email, 'Quiz completado', `+${gain} XP · nivel ${level}`);
  res.json({ level, xp, need: xpForLevel(level), gain, maxLevel: 150 });
});

// ---------- Chatbot asistente (KB + respuesta contextual) ----------
const IPHUB_CONTEXT = `Sos el asistente oficial de IPHub, plataforma de diagnóstico de red.
Secciones: Dashboard (bienvenida, niveles 1-150, XP, actividad), Topología (descubrir red CIDR), Herramientas (IP/geo+VPN/proxy, puertos, traceroute/tracepacket, DNS, subredes, ARP, velocidad), Auditoría (historial con filtros), Aprender (quizzes con cooldown 10 min y XP), Soporte (tickets con adjuntos max 5 archivos / 10MB, reseñas), Mi Cuenta (perfil, foto con Guardar cambios, correo, contraseña, API, eliminar cuenta), Legal.
Auth: captcha, código al correo en login/registro/cambio de correo/eliminar cuenta/recuperar contraseña.
Respondé en el idioma del usuario, de forma clara y útil. Si no sabés algo de IPHub, orientá a la sección correcta.`;

function aiKey() {
  return (process.env.GROQ_API_KEY || process.env.OPENAI_API_KEY || process.env.AI_API_KEY || '').trim();
}
async function aiComplete(prompt, system) {
  const key = aiKey();
  if (!key) {
    console.warn('[AI] Sin API key (GROQ_API_KEY / OPENAI_API_KEY / AI_API_KEY en .env)');
    return null;
  }
  const isGroq = process.env.AI_PROVIDER === 'groq' || key.startsWith('gsk_');
  const url = isGroq ? 'https://api.groq.com/openai/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions';
  const model = process.env.AI_MODEL || (isGroq ? 'llama-3.3-70b-versatile' : 'gpt-4o-mini');
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
      body: JSON.stringify({
        model,
        temperature: 0.55,
        max_tokens: 800,
        messages: [
          { role: 'system', content: system || IPHUB_CONTEXT },
          { role: 'user', content: prompt },
        ],
      }),
    });
    const text = await r.text();
    if (!r.ok) {
      console.error('[AI] HTTP', r.status, text.slice(0, 300));
      return null;
    }
    const d = JSON.parse(text);
    return d.choices?.[0]?.message?.content?.trim() || null;
  } catch (e) {
    console.error('[AI] error', e.message);
    return null;
  }
}

app.post('/api/chat', requireAuth, async (req, res) => {
  const q = String((req.body || {}).message || '').trim().slice(0, 800);
  if (!q) return res.status(400).json({ error: 'Mensaje vacío' });
  const low = q.toLowerCase();
  const rules = [
    [/nivel|xp|experiencia|rango/, 'Tu progreso está en Dashboard y en Aprender. Hay 150 niveles. Cada quiz da XP (cooldown 10 min con contador en vivo).'],
    [/quiz|aprender|pregunta/, 'En Aprender elegís dificultad y respondés quizzes (uno a uno, con feedback inmediato). Suben XP; cooldown 10 minutos.'],
    [/vpn|proxy|proxies/, 'En Herramientas → IP detectamos VPN/proxy por hosting, datacenter y ASN (no Tor).'],
    [/tracepacket|traceroute|traza/, 'Herramientas → Traceroute: Traceroute y Tracepacket con hops y RTT.'],
    [/foto|avatar|perfil/, 'Mi Cuenta: cambiá o quitá la foto y tocá Guardar Cambios.'],
    [/idioma|language|traduc|país|pais/, 'Idioma arriba a la derecha o en Mi Cuenta (iconos de bandera, sin códigos ES/US).'],
    [/cuenta|login|correo|email|contraseña|password/, 'Login/registro con captcha y código al correo. También recuperar contraseña, cambiar correo y eliminar cuenta.'],
    [/windows|exe|app para/, 'Botón App para Windows en el menú lateral descarga el cliente cuando esté en public/download.'],
    [/puerto|scan|escaneo/, 'Herramientas → Puertos: escaneo TCP real solo en equipos que administres.'],
    [/dns|subred|cidr/, 'Herramientas → DNS y Subredes.'],
    [/auditor|historial|filtro/, 'Auditoría con filtros por tipo y fecha.'],
    [/soporte|ticket|reseña|adjunt/, 'Soporte: tickets (hasta 5 adjuntos, 10 MB total) y reseñas editables/eliminables. Todo notifica por correo al equipo.'],
    [/cookie|privacidad/, 'Banner de cookies y sección Legal.'],
  ];
  let answer = null;
  let usedAi = false;
  // Prioridad: IA real si hay clave configurada
  if (aiKey()) {
    answer = await aiComplete(q);
    usedAi = !!answer;
  }
  // Fallback: reglas locales de IPHub
  if (!answer) {
    for (const [re, a] of rules) if (re.test(low)) { answer = a; break; }
  }
  if (!answer) {
    answer = 'Soy el asistente de IPHub. Puedo guiarte por Dashboard, Topología, Herramientas, Auditoría, Aprender, Soporte y Mi Cuenta. Si configuraste GROQ_API_KEY u OPENAI_API_KEY en .env y reiniciaste el servidor, responderé con IA.';
  }
  addAudit(req.user.email, 'Chatbot', q.slice(0, 80));
  res.json({ reply: answer, ai: usedAi });
});

app.post('/api/quiz/generate', requireAuth, async (req, res) => {
  const u = ensureProgress(req.user);
  const now = Date.now();
  const left = Math.max(0, (u.quizAt || 0) + 600000 - now);
  if (left > 0) return res.status(429).json({ error: 'Cooldown activo', quizCooldown: left });
  const difficulty = ['easy', 'medium', 'hard'].includes(req.body?.difficulty) ? req.body.difficulty : 'medium';
  const bank = {
    easy: [
      { q: '¿Qué significa IP en redes?', opts: ['Internet Protocol', 'Internal Port', 'Input Process', 'Instant Packet'], c: 0 },
      { q: 'Puerto por defecto de HTTPS', opts: ['80', '443', '22', '25'], c: 1 },
      { q: '¿Para qué sirve el DNS?', opts: ['Traducir nombres a direcciones IP', 'Cifrar el disco', 'Medir temperatura', 'Abrir puertos al azar'], c: 0 },
      { q: '¿Qué es una dirección MAC?', opts: ['Identificador de hardware en la red local', 'Una contraseña de Wi‑Fi', 'Un tipo de virus', 'Un protocolo de correo'], c: 0 },
      { q: 'IPv4 usa direcciones de', opts: ['32 bits', '64 bits', '128 bits', '8 bits'], c: 0 },
    ],
    medium: [
      { q: 'La máscara de un /24 es', opts: ['255.255.255.0', '255.255.0.0', '255.0.0.0', '255.255.255.255'], c: 0 },
      { q: 'Puerto SSH por defecto', opts: ['21', '22', '23', '3389'], c: 1 },
      { q: 'Traceroute suele basarse en', opts: ['TTL/ICMP o UDP', 'Solo FTP', 'Solo SMTP', 'Solo RDP'], c: 0 },
      { q: 'Un host de datacenter a menudo indica', opts: ['VPN, proxy o servidor en la nube', 'Una impresora casera', 'Solo redes 4G', 'Un cable HDMI'], c: 0 },
      { q: 'CIDR /30 tiene hosts útiles', opts: ['2', '14', '30', '254'], c: 0 },
    ],
    hard: [
      { q: 'El campo TTL en IP sirve para', opts: ['Limitar la cantidad de hops de un paquete', 'Cifrar el payload', 'Asignar la MAC', 'Medir Mbps'], c: 0 },
      { q: 'Un ASN identifica', opts: ['Un sistema autónomo en Internet', 'Un antivirus', 'Una red Wi‑Fi doméstica', 'Un certificado SSL'], c: 0 },
      { q: 'IPv6 usa direcciones de', opts: ['128 bits', '32 bits', '64 bits', '16 bits'], c: 0 },
      { q: 'NAT permite', opts: ['Compartir una IP pública entre varios equipos privados', 'Acelerar siempre el Wi‑Fi', 'Reemplazar el DNS', 'Eliminar la necesidad de firewall'], c: 0 },
      { q: 'Un puerto en estado LISTEN significa', opts: ['Hay un servicio aceptando conexiones', 'El cable está desconectado', 'La IP es inválida', 'Solo hay tráfico UDP broadcast'], c: 0 },
    ],
  };
  // Mezcla aleatoria de 3 preguntas
  let pool = bank[difficulty].slice().sort(() => Math.random() - 0.5);
  // Intentar enriquecer con IA
  const aiRaw = await aiComplete(
    `Generá exactamente 3 preguntas de opción múltiple sobre redes/IP/DNS/TCP (dificultad ${difficulty}). Respondé SOLO JSON válido: [{"q":"...","opts":["a","b","c","d"],"c":0}] donde c es el índice (0-3) de la respuesta correcta.`,
    'Sos un generador de quizzes de redes. Solo devolvés JSON válido, sin markdown.'
  );
  if (aiRaw) {
    try {
      const cleaned = aiRaw.replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length >= 3) {
        pool = parsed.slice(0, 3).map(p => ({
          q: String(p.q || ''),
          opts: Array.isArray(p.opts) ? p.opts.map(String).slice(0, 4) : [],
          c: Math.max(0, Math.min(3, Number(p.c) || 0)),
        })).filter(p => p.q && p.opts.length === 4);
      }
    } catch (_) {}
  }
  if (pool.length < 3) pool = bank[difficulty].slice().sort(() => Math.random() - 0.5);
  const questions = pool.slice(0, 3).map((p, i) => ({ id: i, q: p.q, opts: p.opts, c: p.c }));
  res.json({ difficulty, questions, quizCooldown: 0 });
});


// Cuentas guardadas en el cliente; endpoint solo lista la actual
app.get('/api/accounts/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(ensureProgress(req.user)) });
});

// ---------- Fallback SPA ----------
app.get('/download/agent', (req, res) => {
  const candidates = [
    path.join(__dirname, 'public', 'download', 'IPHub.exe'),
    path.join(__dirname, 'public', 'download', 'IPHub-Monitor.exe'),
    path.join(__dirname, 'public', 'download', 'IPHub-Agent.exe'),
    path.join(__dirname, 'agent', 'dist', 'IPHub-Monitor.exe'),
    path.join(__dirname, 'dist', 'IPHub.exe'),
  ];
  for (const exe of candidates) {
    if (fs.existsSync(exe)) return res.download(exe, 'IPHub.exe');
  }
  res.status(404).type('html').send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>IPHub.exe</title>
  <style>body{font-family:system-ui;background:#0a1628;color:#e2e8f0;padding:2rem;max-width:640px;margin:auto;line-height:1.6}
  code{background:#1e293b;padding:.15rem .4rem;border-radius:4px}</style></head><body>
  <h1>IPHub.exe aún no está compilado</h1>
  <p>En una PC con <strong>Windows</strong> y Node 18+:</p>
  <ol><li><code>npm install</code></li><li><code>npm run build:exe</code></li></ol>
  <p>Sale <code>dist\IPHub.exe</code>. Copialo a <code>public\download\IPHub.exe</code> y este enlace lo servirá para que el usuario solo descargue y listo.</p>
  <p><a href="/home" style="color:#06b6d4">Volver a IPHub</a></p></body></html>`);
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('========================================');
  console.log('  IPHub listo');
  console.log('  Abrí en el navegador:');
  console.log('    http://127.0.0.1:' + PORT);
  console.log('    http://localhost:' + PORT);
  console.log('========================================');
  console.log('  Base de datos: ' + dbFile);
  console.log('  IA chatbot: ' + (aiKey() ? 'ACTIVA (' + (aiKey().startsWith('gsk_') ? 'Groq' : 'OpenAI/otra') + ')' : 'OFF — poné GROQ_API_KEY en .env'));
  console.log('  NO cierres esta ventana.');
  console.log('');
});
