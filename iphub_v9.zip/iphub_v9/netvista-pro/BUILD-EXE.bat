@echo off
chcp 65001 >nul
cd /d "%~dp0"
title IPHub - Build EXE
echo.
echo  Construyendo IPHub.exe (sin firma de codigo)...
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo  ERROR: Node.js no encontrado. Instala desde https://nodejs.org
  pause
  exit /b 1
)

if not exist "node_modules\electron-builder" (
  echo  Instalando dependencias (puede tardar)...
  call npm install
  if errorlevel 1 (
    echo  Fallo npm install
    pause
    exit /b 1
  )
)

set CSC_IDENTITY_AUTO_DISCOVERY=false
set ELECTRON_BUILDER_ALLOW_UNRESOLVED_DEPENDENCIES=true

echo  Ejecutando electron-builder via npx...
call npx --yes electron-builder --win portable --config.win.signAndEditExecutable=false
if errorlevel 1 (
  echo.
  echo  Reintento limpiando cache de winCodeSign...
  rmdir /s /q "%LOCALAPPDATA%\electron-builder\Cache\winCodeSign" 2>nul
  call npx --yes electron-builder --win portable --config.win.signAndEditExecutable=false
)

if exist "dist\IPHub.exe" (
  if not exist "public\download" mkdir "public\download"
  copy /Y "dist\IPHub.exe" "public\download\IPHub.exe" >nul
  echo.
  echo  ========================================
  echo   OK: dist\IPHub.exe
  echo   Copiado a public\download\IPHub.exe
  echo  ========================================
) else if exist "dist\win-unpacked\IPHub.exe" (
  if not exist "public\download" mkdir "public\download"
  copy /Y "dist\win-unpacked\IPHub.exe" "public\download\IPHub.exe" >nul
  echo.
  echo  OK (unpacked): public\download\IPHub.exe
) else (
  echo.
  echo  No se genero el EXE.
  echo  Si el error habla de symbolic link:
  echo   1^) Configuracion - Sistema - Para desarrolladores - Modo de desarrollador ON
  echo   2^) O ejecuta este .bat como Administrador
  echo   3^) Borra: %%LOCALAPPDATA%%\electron-builder\Cache\winCodeSign
  echo   4^) Reintenta
)

echo.
pause
